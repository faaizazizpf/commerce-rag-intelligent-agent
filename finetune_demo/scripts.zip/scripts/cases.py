test_cases=[
"What is the cost of A-999999 freezer",

"Please tell me the haier helpline number ",

"i need a fridge",

"a cheap one",

"also tell the ACs",

"tell me the latest model of haier puri inverter series?",

"Which is haier Best selling washing machine? tell price too.",

"which is the most selling product of haier? tell price too.",

"what is the difference between HWM150-1678 - 15KG and HWM-120AS - 12KG",

"Can you tell me the PEL Refrigerators specifications? ",

"Gree AC is better or Dawlence? ",

"Tell me the Haier product return policy.",

"What is the cost of A-999999 freezer",

"ISs dawlence AC is reliable?",

"Haier candy oven is good? What are the specifications of the latest model?",

"provide me the AC series list having price range 1 lac to 3 lac.",

"What are the key features of Haier's latest smart refrigerator model?",

"Provide me the AC series list with range 20 thousand to 99 thousand.only provide names and price",

"provide top 3 costliest ACs",

"give me the specifications of HWM90-1708S5",

"price as well",

"MRP(Rs) of HWM90-1708S5"
]

fatima_sqa=[
"slam",

"can you please tell me the qualities of brand dawlance?",

"ok so haier's electeronics are worst than dawlance right?",

"My haier ac gets tempered whenever i use it.",
    
"OK so you are saying dawlance ac is good beacuse dawlwance is a good reputed company than haier nice",

"but u claimed before?",

"ok fine",

"no u didnt clarifed me",

"ok tell me about haier branad",

"ok tell me about haier branad",

" ",

"i want to buy ref",

"i want to buy frawks which company i should select?",

"im not talking about ref i want to buy frawks dresses shoes",

"what about haier dresses?",

"ok let me knos about hair machinaery",

"can u provide info of your best selling products details and prices",

"ok tell me dtails of cheapest oven of yours",

"haier website is not workin well. Its very slow",

"cart is not working actually internel is good",

"i need informatuon of golden ac new product of yours",

"its not a new product",

"give me worst ACs you have",

"give me worst ACs you have",

" ",

"I'm sorry, I'm not sure what you are asking. Can you please provide more information or clarify your question?"]

amina_sqa=[
"hello",

"How can you assist me today?",

"I have purchased haier ref, Ref bottom section cooling is not working. But it works fine on upper section",

"I am unable to save temp",

"No, I am talking about ref",


"i am talking about haier ref, you are explained above.",

"ok fine",

"can you please provide me contact number, of your upper management. I'll discuss my issue with them.",

"share website lin",

"share website link",

"please refer new ref",

"haier ref",

"when?",

"tell me your highest price range Chiller",

"I mean standing AC",

"DHST",

"share the best AC models",

"tell me on one, which is latest",

"tell me on one, which is latest",

"what is the price?"]


jz_sqa=[
    
"Why I should choose Haier?",

"But I want to buy Speakers",

"Is it better than JBL?",

"Ok tell me which Haier Inverter AC is better, I want to know the model name.",

"What is it's price?",

"From where you're verifying the price?",

"But I'm from Pakistan tell me the price from the official website of Haier Pakistan.",

"Who tell you to verify prices from Haier India website?",

"But I found gree ac better than Haier ac",

"Tell me is there any kind of gas due to an ac blast",

"Is Haier used this kind of gas which can be the reason of blast AC?",

"But I saw a video on internet in which a guy speak that his Haier AC blasted due to gas.",

"Ok please provide me the link of website the best refrigerator of Haier.",

"Is there any Haier sale on going",

"I have a room 10 * 10, which AC capacity i should use in my room?",

"So which AC should I buy Candy or Haier?",

"Can you give me the answer again of my first message?",

"So you cannot continue the previous chat you just read the current or recent message."]