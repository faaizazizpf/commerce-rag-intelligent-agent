rm -rf /workspace/hf_cache/
mkdir -p /workspace/hf_cache
export HF_HOME=/workspace/hf_cache
python3 dev_app.py
