haier_model_links=[
    {
        "product_info": "H32D2M - 32 Inch H-CAST D2M Series LED",
        "model_number": "H32D2M",
        "link": "https://haier.com.pk/product/145"
    },
    {
        "product_info": "Haier Double Drive Series Washing Machine (HWM 120-1978)",
        "model_number": "HWM 120-1978",
        "link": "https://haier.com.pk/product/186"
    },
    {
        "product_info": "HWM120-35FF - 12KG Single Tub Washer",
        "model_number": "HWM120-35FF",
        "link": "https://haier.com.pk/product/221"
    },
    {
        "product_info": "HWM120-35FF - 12KG Single Tub Washer",
        "model_number": "HWM120-35FF",
        "link": "https://haier.com.pk/product/221"
    },
    {
        "product_info": "HWM120-35FF - 12KG Single Tub Washer",
        "model_number": "HWM120-35FF",
        "link": "https://haier.com.pk/product/221"
    },
    {
        "product_info": "HWM120-35FF - 12KG Single Tub Washer",
        "model_number": "HWM120-35FF",
        "link": "https://haier.com.pk/product/221"
    },
    {
        "product_info": "HWD60-50 - Spinner",
        "model_number": "HWD60-50",
        "link": "https://haier.com.pk/product/223"
    },
    {
        "product_info": "HWD60-50 - Spinner",
        "model_number": "HWD60-50",
        "link": "https://haier.com.pk/product/223"
    },
    {
        "product_info": "HWD60-50 - Spinner",
        "model_number": "HWD60-50",
        "link": "https://haier.com.pk/product/223"
    },
    {
        "product_info": "HWD60-50 - Spinner",
        "model_number": "HWD60-50",
        "link": "https://haier.com.pk/product/223"
    },
    {
        "product_info": "HSU-24HFCD-USDC(W) - 2 Ton Triple Inverter Series Air Conditioner",
        "model_number": "HSU-24HFCD-USDC(W)",
        "link": "https://haier.com.pk/product/1750"
    },
    {
        "product_info": "HMN-20MXP6 - 20L Solo Microwave Oven",
        "model_number": "HMN-20MXP6",
        "link": "https://haier.com.pk/product/1835"
    },
    {
        "product_info": "HMN-45200ESD - 45L Grill Microwave Oven",
        "model_number": "HMN-45200ESD",
        "link": "https://haier.com.pk/product/1836"
    },
    {
        "product_info": "HWM 90-826S5 - 9KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM 90-826S5",
        "link": "https://haier.com.pk/product/1845"
    },
    {
        "product_info": "HRF-368 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2291"
    },
    {
        "product_info": "HRF-368 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2291"
    },
    {
        "product_info": "HRF-368 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2291"
    },
    {
        "product_info": "HRF-368 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2291"
    },
    {
        "product_info": "HRF-398 IAPA+/IARA+ - 14 CFT Digital Inverter series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2292"
    },
    {
        "product_info": "HRF-398 IAPA+/IARA+ - 14 CFT Digital Inverter series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2292"
    },
    {
        "product_info": "HRF-398 IAPA+/IARA+ - 14 CFT Digital Inverter series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2292"
    },
    {
        "product_info": "HRF-398 IAPA+/IARA+ - 14 CFT Digital Inverter series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2292"
    },
    {
        "product_info": "HRF-438 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2293"
    },
    {
        "product_info": "HRF-438 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2293"
    },
    {
        "product_info": "HRF-438 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2293"
    },
    {
        "product_info": "HRF-438 IAPA+/IARA+ - Digital Inverter series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2293"
    },
    {
        "product_info": "Haier Android Dongle (S905Y4)",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2329"
    },
    {
        "product_info": "HSU-12HJ - 1 Ton Puri Inverter Series  Air Conditioner",
        "model_number": "HSU-12HJ",
        "link": "https://haier.com.pk/product/2336"
    },
    {
        "product_info": "HSU-18HJ - 1.5 Ton Puri Inverter Air Conditioner",
        "model_number": "HSU-18HJ",
        "link": "https://haier.com.pk/product/2337"
    },
    {
        "product_info": "HSU-12HJUV - 1 Ton UV Inverter Air Conditioner",
        "model_number": "HSU-12HJUV",
        "link": "https://haier.com.pk/product/2338"
    },
    {
        "product_info": "HSU-18HJUV - 1.5 Ton UV Inverter Air Conditioner",
        "model_number": "HSU-18HJUV",
        "link": "https://haier.com.pk/product/2339"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-12HFPCA/AA/BG-SG-WUSDC - 1 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-12HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2342"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-18HFPCA/AA/BG-SG-WUSDC - 1.5 Ton Pearl Inverter Air Conditioner",
        "model_number": "HSU-18HFPCA/AA/BG-SG-WUSDC",
        "link": "https://haier.com.pk/product/2343"
    },
    {
        "product_info": "HSU-12HFMN/F/AC/AD/AE/DS/CE/CC-WUSDC(W) - 1 Ton Marvel Inverter Air Conditioner",
        "model_number": "HSU-12HFMN/F/AC/AD/AE/DS/CE/CC-WUSDC(W)",
        "link": "https://haier.com.pk/product/2344"
    },
    {
        "product_info": "HSU-18HFMN/F/AC/AD/AE/DG/DS/CE/CC-WUSDC(W) - 1.5 Ton Marvel Inverter Air Conditioner",
        "model_number": "HSU-18HFMN/F/AC/AD/AE/DG/DS/CE/CC-WUSDC(W)",
        "link": "https://haier.com.pk/product/2345"
    },
    {
        "product_info": "HSU-12HFCN/CF/CM/CA/CS-USDC(W) - 1 Ton DC Inverter Air Conditioner",
        "model_number": "HSU-12HFCN/CF/CM/CA/CS-USDC(W)",
        "link": "https://haier.com.pk/product/2346"
    },
    {
        "product_info": "HSU-18HFC - 1.5 Ton Triple Inverter Air Conditioner",
        "model_number": "HSU-18HFC",
        "link": "https://haier.com.pk/product/2347"
    },
    {
        "product_info": "HSU-12LFCM--1 Ton Cool Only Inverter Series Air Conditioner",
        "model_number": "HSU-12LFCM",
        "link": "https://haier.com.pk/product/2348"
    },
    {
        "product_info": "HSU-18LFCM-- Cool Only Inverter Series Air Conditioner",
        "model_number": "HSU-18LFCM",
        "link": "https://haier.com.pk/product/2349"
    },
    {
        "product_info": "HSU-12CFCM - 1 Ton Turbo Cool Air Conditioner",
        "model_number": "HSU-12CFCM",
        "link": "https://haier.com.pk/product/2350"
    },
    {
        "product_info": "HSU-18CFCM - 1.5 Ton Turbo Cool Series Air Conditioner",
        "model_number": "HSU-18CFCM",
        "link": "https://haier.com.pk/product/2351"
    },
    {
        "product_info": "HDF-245 - 8.6 CFT Single Door Regular Deep Freezer",
        "model_number": "HDF-245",
        "link": "https://haier.com.pk/product/2354"
    },
    {
        "product_info": "HDF-285 - 10 CFT  Single Door Regular Deep Freezer",
        "model_number": "HDF-285",
        "link": "https://haier.com.pk/product/2355"
    },
    {
        "product_info": "HDF-345 - 12 CFT Single Door Regular Deep Freezer",
        "model_number": "HDF-345",
        "link": "https://haier.com.pk/product/2356"
    },
    {
        "product_info": "HDF-405 - 14.3 CFT Single Door Deep Freezer",
        "model_number": "HDF-405",
        "link": "https://haier.com.pk/product/2357"
    },
    {
        "product_info": "HDF-545H- 19 CFT Double Door Deep Freezer",
        "model_number": "HDF-545H",
        "link": "https://haier.com.pk/product/2358"
    },
    {
        "product_info": "HDF-230 - 8 CFT Double Door Deep Freezer",
        "model_number": "HDF-230",
        "link": "https://haier.com.pk/product/2359"
    },
    {
        "product_info": "HDF-320 - 11.3 CFT Double Door Deep Freezer",
        "model_number": "HDF-320",
        "link": "https://haier.com.pk/product/2360"
    },
    {
        "product_info": "HDF-385 - 13.6 CFT Double Door Deep Freezer",
        "model_number": "HDF-385",
        "link": "https://haier.com.pk/product/2362"
    },
    {
        "product_info": "HDF-535 - 19 CFT Double Door Regular Deep Freezer",
        "model_number": "HDF-535",
        "link": "https://haier.com.pk/product/2363"
    },
    {
        "product_info": "HDF-245 INV - 8.6 CFT Single Door Inverter Deep Freezer",
        "model_number": "HDF-245 INV",
        "link": "https://haier.com.pk/product/2364"
    },
    {
        "product_info": "HDF-285 INV - 10 CFT Single Door Inverter Deep Freezer",
        "model_number": "HDF-285 INV",
        "link": "https://haier.com.pk/product/2365"
    },
    {
        "product_info": "HDF-405 INV - 14.3 CFT Single Door Inverter Deep Freezer",
        "model_number": "HDF-405 INV",
        "link": "https://haier.com.pk/product/2366"
    },
    {
        "product_info": "HDF-385 INV - 13.6 CFT Double Door Inverter Deep Freezer",
        "model_number": "HDF-385 INV",
        "link": "https://haier.com.pk/product/2368"
    },
    {
        "product_info": "HDF-545 INV - 19.2 CFT Double Door Inverter Deep Freezer",
        "model_number": "HDF-545 INV",
        "link": "https://haier.com.pk/product/2369"
    },
    {
        "product_info": "HRF-186 EBS/EBD - 6.5 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-186 EBS/EBD",
        "link": "https://haier.com.pk/product/2372"
    },
    {
        "product_info": "HRF-186 EBS/EBD - 6.5 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-186",
        "link": "https://haier.com.pk/product/2372"
    },
    {
        "product_info": "HRF-186 EBS/EBD - 6.5 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-186 EBS/EBD",
        "link": "https://haier.com.pk/product/2372"
    },
    {
        "product_info": "HRF-186 EBS/EBD - 6.5 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-186",
        "link": "https://haier.com.pk/product/2372"
    },
    {
        "product_info": "HRF-246 EBS/EBD -9 CFT E-Star Metal Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2374"
    },
    {
        "product_info": "HRF-246 EBS/EBD -9 CFT E-Star Metal Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2374"
    },
    {
        "product_info": "HRF-246 EBS/EBD -9 CFT E-Star Metal Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2374"
    },
    {
        "product_info": "HRF-246 EBS/EBD -9 CFT E-Star Metal Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2374"
    },
    {
        "product_info": "HRF-276 EBS/EBD - 10 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2375"
    },
    {
        "product_info": "HRF-276 EBS/EBD - 10 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2375"
    },
    {
        "product_info": "HRF-276 EBS/EBD - 10 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2375"
    },
    {
        "product_info": "HRF-276 EBS/EBD - 10 CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2375"
    },
    {
        "product_info": "HRF-336 EBS/EBD -12CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-336",
        "link": "https://haier.com.pk/product/2377"
    },
    {
        "product_info": "HRF-336 EBS/EBD -12CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-336",
        "link": "https://haier.com.pk/product/2377"
    },
    {
        "product_info": "HRF-336 EBS/EBD -12CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-336",
        "link": "https://haier.com.pk/product/2377"
    },
    {
        "product_info": "HRF-336 EBS/EBD -12CFT E-Star Metal Door Refrigerator",
        "model_number": "HRF-336",
        "link": "https://haier.com.pk/product/2377"
    },
    {
        "product_info": "HRF-368 IFGA/IFRA - 13CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2388"
    },
    {
        "product_info": "HRF-368 IFGA/IFRA - 13CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2388"
    },
    {
        "product_info": "HRF-368 IFGA/IFRA - 13CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2388"
    },
    {
        "product_info": "HRF-368 IFGA/IFRA - 13CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2388"
    },
    {
        "product_info": "HRF-398 IFGA/IFRA - 14CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2389"
    },
    {
        "product_info": "HRF-398 IFGA/IFRA - 14CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2389"
    },
    {
        "product_info": "HRF-398 IFGA/IFRA - 14CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2389"
    },
    {
        "product_info": "HRF-398 IFGA/IFRA - 14CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2389"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HRF-438 IFGA/IFRA/IFPA - 14.5 CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2390"
    },
    {
        "product_info": "HWM150-826 - 15KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM150-826",
        "link": "https://haier.com.pk/product/2396"
    },
    {
        "product_info": "HWM120-826 - 12KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM120-826",
        "link": "https://haier.com.pk/product/2397"
    },
    {
        "product_info": "HWM120-826E - 12KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM120-826E",
        "link": "https://haier.com.pk/product/2398"
    },
    {
        "product_info": "HWM85-826 - 8.5KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM85-826",
        "link": "https://haier.com.pk/product/2399"
    },
    {
        "product_info": "HWM80-1708Y - 8KG Top Load Fully Automatic Washing Machine",
        "model_number": "HWM80-1708Y",
        "link": "https://haier.com.pk/product/2402"
    },
    {
        "product_info": "HWM80-35 - 8KG Single Tub Washer",
        "model_number": "HWM80-35",
        "link": "https://haier.com.pk/product/2406"
    },
    {
        "product_info": "HWM80-35 - 8KG Single Tub Washer",
        "model_number": "HWM80-35",
        "link": "https://haier.com.pk/product/2406"
    },
    {
        "product_info": "HWM80-35 - 8KG Single Tub Washer",
        "model_number": "HWM80-35",
        "link": "https://haier.com.pk/product/2406"
    },
    {
        "product_info": "HWM80-35 - 8KG Single Tub Washer",
        "model_number": "HWM80-35",
        "link": "https://haier.com.pk/product/2406"
    },
    {
        "product_info": "Haier Double Tub Washing Machine (HWM-100AS)",
        "model_number": "HWM-100AS",
        "link": "https://haier.com.pk/product/2415"
    },
    {
        "product_info": "HWM-100BS - 10KG Twin Tub  Semi Automatic Washing Machine",
        "model_number": "HWM-100BS",
        "link": "https://haier.com.pk/product/2416"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-216 EPR/EPB/EPC/EPG - 7.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/2431"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-246 EPR/EPB/EPC/EPG - 8.6 CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-246",
        "link": "https://haier.com.pk/product/2432"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-276 EPR/EPB/EPC/EPG - 10CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-276",
        "link": "https://haier.com.pk/product/2433"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-368 EPR/EPB/EPC/EPG - 13CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-368",
        "link": "https://haier.com.pk/product/2436"
    },
    {
        "product_info": "HRF-398 EPR/EPB/EPC/EPG - 14CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2437"
    },
    {
        "product_info": "HRF-398 EPR/EPB/EPC/EPG - 14CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2437"
    },
    {
        "product_info": "HRF-398 EPR/EPB/EPC/EPG - 14CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2437"
    },
    {
        "product_info": "HRF-398 EPR/EPB/EPC/EPG - 14CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-398",
        "link": "https://haier.com.pk/product/2437"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "HRF-438 EPR/EPB/EPG - 15CFT E-Star Glass Door Series Refrigerator",
        "model_number": "HRF-438",
        "link": "https://haier.com.pk/product/2438"
    },
    {
        "product_info": "Haier Double Drive Series Washing Machine (HWM 150-1978)",
        "model_number": "HWM 150-1978",
        "link": "https://haier.com.pk/product/3353"
    },
    {
        "product_info": "HMN-20MXP5 - 20L Solo Microwave Oven",
        "model_number": "HMN-20MXP5",
        "link": "https://haier.com.pk/product/3474"
    },
    {
        "product_info": "HWM-120AS - 12KG Twin Tub Semi Automatic Washing Machine",
        "model_number": "HWM-120AS",
        "link": "https://haier.com.pk/product/3889"
    },
    {
        "product_info": "HRF-216 EBS/EBD - 7.5 CFT E-Star Metal Door Series Refrigerator",
        "model_number": "HRF-216",
        "link": "https://haier.com.pk/product/3902"
    },
    {
        "product_info": "HSU-18HFTCA(S) - 1.5 Ton Thunder Series T3 DC Inverter",
        "model_number": "HSU-18HFTCA(S)",
        "link": "https://haier.com.pk/product/4133"
    },
    {
        "product_info": "HSU-18HFTCD(W)- 1.5 Ton Thunder Series T3 DC Inverter",
        "model_number": "HSU-18HFTCD(W)",
        "link": "https://haier.com.pk/product/4134"
    },
    {
        "product_info": "CSU-12HF - 1 Ton Heat & Cool DC Inverter",
        "model_number": "CSU-12HF",
        "link": "https://haier.com.pk/product/4135"
    },
    {
        "product_info": "CSU-18HF - 1.5 Ton Heat & Cool DC Inverter ",
        "model_number": "CSU-18HF",
        "link": "https://haier.com.pk/product/4136"
    },
    {
        "product_info": "HSU-12RFP - 1 Ton RF Series DC Inverter",
        "model_number": "HSU-12RFP",
        "link": "https://haier.com.pk/product/4138"
    },
    {
        "product_info": "HSU-18RFP - 1.5 Ton RF Series DC Inverter ",
        "model_number": "HSU-18RFP",
        "link": "https://haier.com.pk/product/4139"
    },
    {
        "product_info": "H32K800X - 32 Inch Google TV ",
        "model_number": "H32K800X",
        "link": "https://haier.com.pk/product/4140"
    },
    {
        "product_info": "H43K800FX - 43 Inch Google TV",
        "model_number": "H43K800FX",
        "link": "https://haier.com.pk/product/4141"
    },
    {
        "product_info": "H43S800UX - 43 Inch Google LED",
        "model_number": "H43S800UX",
        "link": "https://haier.com.pk/product/4146"
    },
    {
        "product_info": "H50S800UX - 50 Inch Google TV",
        "model_number": "H50S800UX",
        "link": "https://haier.com.pk/product/4147"
    },
    {
        "product_info": "H55S800UX - 55 Inch Google TV",
        "model_number": "H55S800UX",
        "link": "https://haier.com.pk/product/4148"
    },
    {
        "product_info": "H65S800UX - 65 Inch Google TV",
        "model_number": "H65S800UX",
        "link": "https://haier.com.pk/product/4149"
    },
    {
        "product_info": "HGL-20MXP7 - 20L Solo Microwave Oven",
        "model_number": "HGL-20MXP7",
        "link": "https://haier.com.pk/product/4160"
    },
    {
        "product_info": "HGL-20MXP8 - 20L Solo Microwave Oven",
        "model_number": "HGL-20MXP8",
        "link": "https://haier.com.pk/product/4161"
    },
    {
        "product_info": "HGL-25MXP8 - 25 L Solo Microwave Oven",
        "model_number": "HGL-25MXP8",
        "link": "https://haier.com.pk/product/4162"
    },
    {
        "product_info": "HGL-30100 - 30L Rotisserie/Grill/Convection/Baking Microwave Oven",
        "model_number": "HGL-30100",
        "link": "https://haier.com.pk/product/4166"
    },
    {
        "product_info": "HMN-62MX80 - 62L Solo Microwave Oven",
        "model_number": "HMN-62MX80",
        "link": "https://haier.com.pk/product/4167"
    },
    {
        "product_info": "HMN-32100BEGB - 32L Grill Microwave Oven",
        "model_number": "HMN-32100BEGB",
        "link": "https://haier.com.pk/product/4168"
    },
    {
        "product_info": "HRF-538 EPR/EPG - 19 CFT E-Star Refrigerator",
        "model_number": "HRF-538 EPR/EPG",
        "link": "https://haier.com.pk/product/4169"
    },
    {
        "product_info": "HRF-538 EPR/EPG - 19 CFT E-Star Refrigerator",
        "model_number": "HRF-538 EPR/EPG",
        "link": "https://haier.com.pk/product/4169"
    },
    {
        "product_info": "HRF-538 EPR/EPG - 19 CFT E-Star Refrigerator",
        "model_number": "HRF-538 EPR/EPG",
        "link": "https://haier.com.pk/product/4169"
    },
    {
        "product_info": "HRF-538 EPR/EPG - 19 CFT E-Star Refrigerator",
        "model_number": "HRF-538 EPR/EPG",
        "link": "https://haier.com.pk/product/4169"
    },
    {
        "product_info": "HRF-538 IAPA+/IARA+-  12CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538 IAPA+/IARA+",
        "link": "https://haier.com.pk/product/4175"
    },
    {
        "product_info": "HRF-538 IAPA+/IARA+-  12CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4175"
    },
    {
        "product_info": "HRF-538 IAPA+/IARA+-  12CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538 IAPA+/IARA+",
        "link": "https://haier.com.pk/product/4175"
    },
    {
        "product_info": "HRF-538 IAPA+/IARA+-  12CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4175"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HRF-538 IFGA/IFRA/IFPA - 10CFT Digital Inverter Refrigerator",
        "model_number": "HRF-538",
        "link": "https://haier.com.pk/product/4177"
    },
    {
        "product_info": "HWM95-1678ES8 - 9.5kg Fully Automatic Top Load Washing Machine",
        "model_number": "HWM95-1678ES8",
        "link": "https://haier.com.pk/product/4178"
    },
    {
        "product_info": "HRF-622IBS - 22CFT - Side by Side Digital Inverter Refrigerator ",
        "model_number": "HRF-622IBS",
        "link": "https://haier.com.pk/product/4195"
    },
    {
        "product_info": "HRF-622ICG - 22CFT - Side by Side Digital Inverter Refrigerator ",
        "model_number": "HRF-622ICG",
        "link": "https://haier.com.pk/product/4196"
    },
    {
        "product_info": "HRF-622IBG - 22CFT - Side by Side Digital Inverter Refrigerator",
        "model_number": "HRF-622IBG",
        "link": "https://haier.com.pk/product/4197"
    },
    {
        "product_info": "HWM150-1678ES8 -  Fully Automatic Top Load Washing Machine",
        "model_number": "HWM150-1678ES8",
        "link": "https://haier.com.pk/product/4200"
    },
    {
        "product_info": "HW80-BP12929S3 - 8 kg - Fully Automatic Front Load Washing Machine",
        "model_number": "HW80-BP12929S3",
        "link": "https://haier.com.pk/product/4201"
    },
    {
        "product_info": "HW90-BP14959S8 - 9 kg Fully Automatic Front Load Washing Machine",
        "model_number": "HW90-BP14959S8",
        "link": "https://haier.com.pk/product/4202"
    },
    {
        "product_info": "HW100-BP14929S3 - 10 kg Fully Automatic Front Load Washing Machine",
        "model_number": "HW100-BP14929S3",
        "link": "https://haier.com.pk/product/4203"
    },
    {
        "product_info": "Candy - C40K6FG - 40 Inch Smart Android LED TV",
        "model_number": "C40K6FG",
        "link": "https://haier.com.pk/product/4205"
    },
    {
        "product_info": "Candy - C32K7G - 32 Inch Android Smart LED TV",
        "model_number": "C32K7G",
        "link": "https://haier.com.pk/product/4206"
    },
    {
        "product_info": "Candy - C50K7UG - 50 Inch Smart Android LED TV",
        "model_number": "C50K7UG",
        "link": "https://haier.com.pk/product/4207"
    },
    {
        "product_info": "Candy - C55K7UG - 55 Inch Android Smart LED TV",
        "model_number": "C55K7UG",
        "link": "https://haier.com.pk/product/4208"
    },
    {
        "product_info": "Candy - CDL-20MX01 - 20L Solo Microwave Oven",
        "model_number": "CDL-20MX01",
        "link": "https://haier.com.pk/product/4209"
    },
    {
        "product_info": "Candy - CDL-25DG02 -25L - Grill Microwave Oven",
        "model_number": "CDL-25DG02",
        "link": "https://haier.com.pk/product/4210"
    },
    {
        "product_info": "HMW-20MBS - Haier Solo Microwave Oven",
        "model_number": "HMW-20MBS",
        "link": "https://haier.com.pk/product/4219"
    },
    {
        "product_info": "HMW-20MX12 20L Solo Microwave Oven",
        "model_number": "HMW-20MX12",
        "link": "https://haier.com.pk/product/4220"
    },
    {
        "product_info": " HMW-20MX11 20L Solo Microwave Oven ",
        "model_number": "HMW-20MX11",
        "link": "https://haier.com.pk/product/4221"
    },
    {
        "product_info": " HMW-20DSS-20L Digital Solo Microwave Oven ",
        "model_number": "HMW-20DSS",
        "link": "https://haier.com.pk/product/4222"
    },
    {
        "product_info": " HMW-20DGS-20L Digital Grill Microwave Oven ",
        "model_number": "HMW-20DGS",
        "link": "https://haier.com.pk/product/4223"
    },
    {
        "product_info": " HMW-23200-23L Digital Microwave Oven ",
        "model_number": "HMW-23200",
        "link": "https://haier.com.pk/product/4224"
    },
    {
        "product_info": " HMW-28100-28L Digital Grill Microwave Oven ",
        "model_number": "HMW-28100",
        "link": "https://haier.com.pk/product/4225"
    },
    {
        "product_info": "HWM 75-AS / 7.5kg/ SEMI AUTOMATIC TWIN TUB WASHING MACHINE ",
        "model_number": "Not Found",
        "link": "https://haier.com.pk/product/4226"
    },
    {
        "product_info": "Haier -10kg/ Twin Tub / Semi Automatic/ HWM 100-AS",
        "model_number": "Not Found",
        "link": "https://haier.com.pk/product/4227"
    },
    {
        "product_info": "HWM 80-1269X-Haier-8 kg-Fully Automatic-Top Loading Washing Machine",
        "model_number": "Not Found",
        "link": "https://haier.com.pk/product/4228"
    },
    {
        "product_info": "Haier -08kg/ Twin Tub / Semi Automatic/ HWM 80-AS ",
        "model_number": "Not Found",
        "link": "https://haier.com.pk/product/4230"
    },
    {
        "product_info": "Haier IG Deep Freezer HDF 385 IG ",
        "model_number": "Not Found",
        "link": "https://haier.com.pk/product/4231"
    },
    {
        "product_info": "HRF 538 IOT-HRF-538TIFGU1- Twin Inverter",
        "model_number": "HRF 538",
        "link": "https://haier.com.pk/product/4232"
    },
    {
        "product_info": "HRF 316IPRA/IPGA- 11 cubic feet-smart Inverter",
        "model_number": "HRF 316IPRA/IPGA",
        "link": "https://haier.com.pk/product/4233"
    },
    {
        "product_info": "HRF 316IPRA/IPGA- 11 cubic feet-smart Inverter",
        "model_number": "HRF 316IPRA/IPGA",
        "link": "https://haier.com.pk/product/4233"
    },
    {
        "product_info": "HRF 316IPRA/IPGA- 11 cubic feet-smart Inverter",
        "model_number": "HRF 316IPRA/IPGA",
        "link": "https://haier.com.pk/product/4233"
    },
    {
        "product_info": "HRF 316IPRA/IPGA- 11 cubic feet-smart Inverter",
        "model_number": "HRF 316IPRA/IPGA",
        "link": "https://haier.com.pk/product/4233"
    },
    {
        "product_info": "HRF 346 IPRA/IPGA-12 cubic feet- Smart Inverter",
        "model_number": "HRF 346 IPRA/IPGA",
        "link": "https://haier.com.pk/product/4234"
    },
    {
        "product_info": "HRF 346 IPRA/IPGA-12 cubic feet- Smart Inverter",
        "model_number": "HRF 346 IPRA/IPGA",
        "link": "https://haier.com.pk/product/4234"
    },
    {
        "product_info": "HRF 346 IPRA/IPGA-12 cubic feet- Smart Inverter",
        "model_number": "HRF 346 IPRA/IPGA",
        "link": "https://haier.com.pk/product/4234"
    },
    {
        "product_info": "HRF 346 IPRA/IPGA-12 cubic feet- Smart Inverter",
        "model_number": "HRF 346 IPRA/IPGA",
        "link": "https://haier.com.pk/product/4234"
    },
    {
        "product_info": "HSU 24HFPCA(S/G)- 2 Ton DC inverter",
        "model_number": "HSU 24HFPCA(S/G)",
        "link": "https://haier.com.pk/product/4235"
    },
    {
        "product_info": "HSU 24HFPCA(S/G)- 2 Ton DC inverter",
        "model_number": "HSU 24HFPCA(S/G)",
        "link": "https://haier.com.pk/product/4235"
    },
    {
        "product_info": "HSU 24HFPCA(S/G)- 2 Ton DC inverter",
        "model_number": "HSU 24HFPCA(S/G)",
        "link": "https://haier.com.pk/product/4235"
    },
    {
        "product_info": "HSU 24HFPCA(S/G)- 2 Ton DC inverter",
        "model_number": "HSU 24HFPCA(S/G)",
        "link": "https://haier.com.pk/product/4235"
    },
    {
        "product_info": "HWM 20 MHES-Haier Solo Microwave Oven",
        "model_number": "HWM 20 MHES",
        "link": "https://haier.com.pk/product/4237"
    },
    {
        "product_info": "HWM-30AFR-AirFryer Series",
        "model_number": "HWM-30AFR",
        "link": "https://haier.com.pk/product/4238"
    },
    {
        "product_info": "HDF-465-Single Door Deep Freezer",
        "model_number": "HDF-465",
        "link": "https://haier.com.pk/product/4239"
    },
    {
        "product_info": "Haier 130-1217-13kg Single Tub Semi Automatic Washing Machine",
        "model_number": "130-1217",
        "link": "https://haier.com.pk/product/4240"
    },
    {
        "product_info": "HWM-85-826E- 8.5 kg Fully Automatic Washing Machine",
        "model_number": "HWM-85-826E",
        "link": "https://haier.com.pk/product/4241"
    },
    {
        "product_info": "HWM 80-1217-8kg Single Tub Semi Automatic Washing Machine",
        "model_number": "80-1217",
        "link": "https://haier.com.pk/product/4242"
    },
    {
        "product_info": "HW80-BP12929S6 - 8 kg Fully Automatic Front Load Washing Machine",
        "model_number": "HW80-BP12929S6",
        "link": "https://haier.com.pk/product/4243"
    },
    {
        "product_info": "HW100-BP14929S6 - 10 kg Fully Automatic Front Load Washing Machine",
        "model_number": "HW100-BP14929S6",
        "link": "https://haier.com.pk/product/4244"
    },
    {
        "product_info": "HW105-B14959S8U1-10.5 Front Load Fully Automatic Washing Machine",
        "model_number": "HW105-B14959S8U1",
        "link": "https://haier.com.pk/product/4245"
    },
    {
        "product_info": "HWD105-B14959S8U1-10.5 Front Load Fully Automatic Washing Machine",
        "model_number": "HWD105-B14959S8U1",
        "link": "https://haier.com.pk/product/4246"
    },
    {
        "product_info": "HWM-30AFS-AirFryer Series",
        "model_number": "30AFS",
        "link": "https://haier.com.pk/product/4247"
    },
    {
        "product_info": "HWM 20MWS solo microwave oven",
        "model_number": "20MWS",
        "link": "https://haier.com.pk/product/4248"
    },
    {
        "product_info": "HWM 120-1678ES8-12kg Top Load Fully Automatic Washing Machine",
        "model_number": "120-1678ES8",
        "link": "https://haier.com.pk/product/4249"
    },
    {
        "product_info": "HWM 150-B1678ES8-15Kg Fully Automatic Top Load Washing Machine",
        "model_number": "150-B1678ES8",
        "link": "https://haier.com.pk/product/4250"
    },
    {
        "product_info": "HWM 120-B1678ES8- 12Kg Fully Top Load Automatic Washing Machine",
        "model_number": "120-B1678ES8",
        "link": "https://haier.com.pk/product/4251"
    },
    {
        "product_info": "H32S80EFX- Full HD QLED Google TV",
        "model_number": "H32S80EFX",
        "link": "https://haier.com.pk/product/4252"
    },
    {
        "product_info": "H50S80EUX- 4K QLED Google TV",
        "model_number": "H50S80EUX",
        "link": "https://haier.com.pk/product/4253"
    },
    {
        "product_info": "H55S80EUX-4K QLED Google TV",
        "model_number": "H55S80EUX",
        "link": "https://haier.com.pk/product/4254"
    },
    {
        "product_info": "H65S80EUX- 4K QLED Google TV",
        "model_number": "H65S80EUX",
        "link": "https://haier.com.pk/product/4255"
    },
    {
        "product_info": "H75S80EUX-4K QLED Google TV",
        "model_number": "H75S80EUX",
        "link": "https://haier.com.pk/product/4256"
    },
    {
        "product_info": "HRF-316 IFGA- 11CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-316 IFGA",
        "link": "https://haier.com.pk/product/4257"
    },
    {
        "product_info": "HRF-316 IFGA- 11CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-316 IFGA",
        "link": "https://haier.com.pk/product/4257"
    },
    {
        "product_info": "HRF-316 IFGA- 11CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-316 IFGA",
        "link": "https://haier.com.pk/product/4257"
    },
    {
        "product_info": "HRF-316 IFGA- 11CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-316 IFGA",
        "link": "https://haier.com.pk/product/4257"
    },
    {
        "product_info": "HRF-346 IFGA/IFRA- 12CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-346 IFGA/IFRA",
        "link": "https://haier.com.pk/product/4258"
    },
    {
        "product_info": "HRF-346 IFGA/IFRA- 12CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-346",
        "link": "https://haier.com.pk/product/4258"
    },
    {
        "product_info": "HRF-346 IFGA/IFRA- 12CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-346 IFGA/IFRA",
        "link": "https://haier.com.pk/product/4258"
    },
    {
        "product_info": "HRF-346 IFGA/IFRA- 12CFT HCS Digital Inverter Refrigerator",
        "model_number": "HRF-346",
        "link": "https://haier.com.pk/product/4258"
    },
    {
        "product_info": "HR-66 B-2.5CFT Single Door  Refrigerator",
        "model_number": "HR-66",
        "link": "https://haier.com.pk/product/4259"
    },
    {
        "product_info": "HWM 100-316S6- 10KG Fully Automatic Top Load Washing Machine",
        "model_number": "HWM 100-316S6",
        "link": "https://haier.com.pk/product/4260"
    },
    {
        "product_info": "HWM 120-316S6- 12KG Fully Automatic Top Load Washing Machine",
        "model_number": "HWM 120-316S6",
        "link": "https://haier.com.pk/product/4261"
    },
    {
        "product_info": "HWM 150-316S6- 15KG Fully Automatic Top Load Washing Machine",
        "model_number": "HWM 150-316S6",
        "link": "https://haier.com.pk/product/4262"
    }
]